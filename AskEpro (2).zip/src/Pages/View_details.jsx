import React from 'react';
import { Container, Grid } from "semantic-ui-react";

const View_details = () => {
    return (
        <>
        <h2>Application Details</h2>
            

        </>
    );

}

export default View_details;