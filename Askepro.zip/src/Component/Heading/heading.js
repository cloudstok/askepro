import React from 'react';
import {Header} from 'semantic-ui-react';

const Heading = () => <Header as='h1'>Fill in details & apply now</Header>

export default Heading;